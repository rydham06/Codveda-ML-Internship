Codveda Machine Learning Internship

Tasks Completed:

Level 1:
1. Data Preprocessing for Machine Learning
2. Linear Regression Model

Level 2:
1. Logistic Regression
2. Decision Tree Classification

Level 3:
1. Random Forest Classification
2. Support Vector Machine (SVM)

Tools Used:
Python
Pandas
Scikit-Learn
Matplotlib

Submitted By:
Rydham