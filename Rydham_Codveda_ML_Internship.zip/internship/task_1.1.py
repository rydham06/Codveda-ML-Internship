print("="*50)
print("TASK 1: DATA PREPROCESSING FOR MACHINE LEARNING")
print("="*50)
import os
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

input_path = "titanic_dataset.csv"
output_path = "processed_titanic.csv"

if not os.path.exists(input_path):
    raise FileNotFoundError(f"Input file not found: {input_path}")

print("Loading dataset from:", input_path)
df = pd.read_csv(input_path)

rename_map = {}
if "Passengerid" in df.columns:
    rename_map["Passengerid"] = "PassengerId"
if "2urvived" in df.columns:
    rename_map["2urvived"] = "Survived"
if rename_map:
    df = df.rename(columns=rename_map)

print("Columns:", list(df.columns))
print("Missing values before preprocessing:\n", df.isnull().sum())

if "Age" in df.columns:
    df["Age"] = df["Age"].fillna(df["Age"].median())

if "Embarked" in df.columns:
    df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

if "Sex" in df.columns and df["Sex"].dtype == object:
    df["Sex"] = df["Sex"].map({"male": 0, "female": 1})

if "Embarked" in df.columns and df["Embarked"].dtype == object:
    df = pd.get_dummies(df, columns=["Embarked"], drop_first=True)

# Drop unnecessary columns
unneeded = ["PassengerId", "Name", "Ticket", "Cabin"]
unneeded = [c for c in unneeded if c in df.columns]
if unneeded:
    df = df.drop(columns=unneeded)

numeric_features = [col for col in ["Age", "Fare"] if col in df.columns]
if numeric_features:
    scaler = StandardScaler()
    df[numeric_features] = scaler.fit_transform(df[numeric_features])

print("Missing values after preprocessing:\n", df.isnull().sum())
df.to_csv(output_path, index=False)
print(f"Processed dataset saved to: {output_path}")

if "Survived" in df.columns:
    X = df.drop("Survived", axis=1)
    y = df["Survived"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    print("Train/Test split completed:")
    print("  X_train shape:", X_train.shape)
    print("  X_test shape:", X_test.shape)
    print("  y_train shape:", y_train.shape)
    print("  y_test shape:", y_test.shape)
else:
    print("Warning: target column 'Survived' not found. Skipping train/test split.")

    print("\nPreprocessing completed successfully!")
print(f"Processed dataset shape: {df.shape}")
