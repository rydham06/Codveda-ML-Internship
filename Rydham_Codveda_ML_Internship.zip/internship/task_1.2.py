print("="*60)
print("TASK 1.2 : LINEAR REGRESSION FOR HOUSE RENT PREDICTION")
print("="*60)
import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

input_path = "House_Rent_Dataset.csv"

if not os.path.exists(input_path):
    raise FileNotFoundError(f"Input file not found: {input_path}")

print("Loading dataset from:", input_path)
df = pd.read_csv(input_path)
print("Columns:", df.columns.tolist())

features = ["Size", "BHK", "Bathroom"]
target = "Rent"
missing = [col for col in features + [target] if col not in df.columns]
if missing:
    raise KeyError(f"Missing expected columns: {missing}")

X = df[features].copy()
y = df[target].copy()

for col in X.columns:
    X[col] = pd.to_numeric(X[col], errors="coerce")
y = pd.to_numeric(y, errors="coerce")

valid = X.notna().all(axis=1) & y.notna()
X = X.loc[valid]
y = y.loc[valid]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)
pred = model.predict(X_test)

print("R2 Score:", r2_score(y_test, pred))
print("MSE:", mean_squared_error(y_test, pred))
print("\nFeature Coefficients:")
for feature, coef in zip(features, model.coef_):
    print(f"{feature}: {coef:.4f}")
