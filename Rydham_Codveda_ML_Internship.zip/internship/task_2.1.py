from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_curve,
    auc
)

import numpy as np
import matplotlib.pyplot as plt

print("=" * 60)
print("TASK 2.1 : LOGISTIC REGRESSION FOR BINARY CLASSIFICATION")
print("=" * 60)

# Load Dataset
data = load_breast_cancer()

X = data.data
y = data.target

print("\nDataset Shape:", X.shape)
print("Number of Features:", len(data.feature_names))

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("\nTrain/Test Split Completed")
print("X_train Shape:", X_train.shape)
print("X_test Shape :", X_test.shape)

# Train Model
model = LogisticRegression(max_iter=5000)

model.fit(X_train, y_train)

# Predictions
pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, pred)

print("\nAccuracy Score:")
print(accuracy)

# Confusion Matrix
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, pred))

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, pred))

# Coefficients
print("\nFirst 10 Feature Coefficients:")

for feature, coef in zip(data.feature_names[:10], model.coef_[0][:10]):
    print(f"{feature}: {coef:.4f}")

# Odds Ratio
print("\nFirst 10 Odds Ratios:")

odds_ratio = np.exp(model.coef_[0])

for feature, odds in zip(data.feature_names[:10], odds_ratio[:10]):
    print(f"{feature}: {odds:.4f}")

# ROC Curve
y_prob = model.predict_proba(X_test)[:, 1]

fpr, tpr, thresholds = roc_curve(y_test, y_prob)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8, 6))

plt.plot(
    fpr,
    tpr,
    label=f"ROC Curve (AUC = {roc_auc:.2f})"
)

plt.plot(
    [0, 1],
    [0, 1],
    linestyle="--"
)

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - Logistic Regression")
plt.legend()

plt.savefig("task_2.1_roc_curve.png")

plt.show()

print("\nROC Curve saved as: task_2.1_roc_curve.png")
print("\nTask Completed Successfully!")