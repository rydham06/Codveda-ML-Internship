from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split

# Load:
iris = load_iris()
X = iris.data
y = iris.target

# Split data:
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train:
from sklearn.tree import DecisionTreeClassifier

model = DecisionTreeClassifier(
    max_depth=3,
    random_state=42
)

model.fit(X_train, y_train)

# Visualize Tree
import matplotlib.pyplot as plt
from sklearn.tree import plot_tree

plt.figure(figsize=(12,8))

plot_tree(
    model,
    filled=True
)

plt.show()

from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score