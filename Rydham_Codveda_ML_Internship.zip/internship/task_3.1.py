from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

import matplotlib.pyplot as plt
import pandas as pd

print("=" * 60)
print("TASK 3.1 : RANDOM FOREST CLASSIFIER")
print("=" * 60)

# Load Dataset
data = load_breast_cancer()

X = data.data
y = data.target

print("\nDataset Loaded Successfully")
print("Dataset Shape:", X.shape)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("\nTrain/Test Split Completed")
print("X_train Shape:", X_train.shape)
print("X_test Shape :", X_test.shape)

# Random Forest Model
model = RandomForestClassifier(
    n_estimators=100,
    max_depth=5,
    random_state=42
)

# Train Model
model.fit(X_train, y_train)

print("\nRandom Forest Model Trained Successfully")

# Predictions
pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, pred)

print("\nAccuracy Score:")
print(accuracy)

# Confusion Matrix
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, pred))

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, pred))

# Cross Validation
cv_scores = cross_val_score(model, X, y, cv=5)

print("\nCross Validation Scores:")
print(cv_scores)

print("\nAverage Cross Validation Score:")
print(cv_scores.mean())

# Feature Importance
importance = model.feature_importances_

feature_importance = pd.DataFrame({
    "Feature": data.feature_names,
    "Importance": importance
})

feature_importance = feature_importance.sort_values(
    by="Importance",
    ascending=False
)

print("\nTop 10 Important Features:")
print(feature_importance.head(10))

# Feature Importance Graph
plt.figure(figsize=(10, 6))

plt.bar(
    feature_importance["Feature"][:10],
    feature_importance["Importance"][:10]
)

plt.xticks(rotation=90)

plt.xlabel("Features")
plt.ylabel("Importance Score")
plt.title("Top 10 Feature Importances")

plt.tight_layout()

plt.savefig("task_3.1_feature_importance.png")

plt.show()

print("\nFeature Importance Graph Saved:")
print("task_3.1_feature_importance.png")

print("\nTask Completed Successfully!")