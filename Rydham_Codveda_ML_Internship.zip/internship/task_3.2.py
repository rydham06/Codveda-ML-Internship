from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_curve,
    auc
)

import matplotlib.pyplot as plt

print("=" * 60)
print("TASK 3.2 : SUPPORT VECTOR MACHINE (SVM)")
print("=" * 60)

# Load Dataset
data = load_breast_cancer()

X = data.data
y = data.target

print("\nDataset Loaded Successfully")
print("Dataset Shape:", X.shape)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("\nTrain/Test Split Completed")

# Linear Kernel
linear_model = SVC(
    kernel='linear',
    probability=True,
    random_state=42
)

# RBF Kernel
rbf_model = SVC(
    kernel='rbf',
    probability=True,
    random_state=42
)

# Train Models
linear_model.fit(X_train, y_train)
rbf_model.fit(X_train, y_train)

# Predictions
pred_linear = linear_model.predict(X_test)
pred_rbf = rbf_model.predict(X_test)

# Accuracy Comparison
accuracy_linear = accuracy_score(y_test, pred_linear)
accuracy_rbf = accuracy_score(y_test, pred_rbf)

print("\nLinear Kernel Accuracy:")
print(accuracy_linear)

print("\nRBF Kernel Accuracy:")
print(accuracy_rbf)

best = "Linear" if accuracy_linear >= accuracy_rbf else "RBF"

print(f"\nBest Model: {best} Kernel")

# Classification Report
print("\nClassification Report (Linear Kernel):")
print(classification_report(y_test, pred_linear))

# Confusion Matrix
print("\nConfusion Matrix (Linear Kernel):")
print(confusion_matrix(y_test, pred_linear))

# ROC Curve
y_prob = linear_model.predict_proba(X_test)[:, 1]

fpr, tpr, _ = roc_curve(y_test, y_prob)

roc_auc = auc(fpr, tpr)

print("\nAUC Score:")
print(roc_auc)

# Plot ROC Curve
plt.figure(figsize=(8, 6))

plt.plot(
    fpr,
    tpr,
    label=f"ROC Curve (AUC = {roc_auc:.2f})"
)

plt.plot([0, 1], [0, 1], linestyle="--")

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - SVM")
plt.legend()

plt.savefig("task_3.2_roc_curve.png")

plt.show()

print("\nROC Curve saved as:")
print("task_3.2_roc_curve.png")

print("\nTask Completed Successfully!")